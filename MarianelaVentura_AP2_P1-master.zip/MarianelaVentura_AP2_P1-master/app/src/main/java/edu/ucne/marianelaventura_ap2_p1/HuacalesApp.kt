package edu.ucne.marianelaventura_ap2_p1

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HuacalesApp : Application()