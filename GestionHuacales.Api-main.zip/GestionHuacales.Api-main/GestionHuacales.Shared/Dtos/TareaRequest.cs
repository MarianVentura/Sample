﻿namespace GestionHuacales.Shared.Dtos;

public record TareaRequest(string Descripcion, bool EstaCompletada);