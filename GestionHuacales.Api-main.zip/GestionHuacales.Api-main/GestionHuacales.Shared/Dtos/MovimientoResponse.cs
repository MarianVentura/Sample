namespace GestionHuacales.Shared.Dtos;

public class MovimientoResponse
{
    public string Jugador { get; set; } = "X";

    public int PosicionFila { get; set; }

    public int PosicionColumna { get; set; }
}
