﻿namespace GestionHuacales.Api.DTO;

public class PartidaResponse
{
    public int PartidaId { get; set; }
    public int Jugador1Id { get; set; }
    public int? Jugador2Id { get; set; }
}