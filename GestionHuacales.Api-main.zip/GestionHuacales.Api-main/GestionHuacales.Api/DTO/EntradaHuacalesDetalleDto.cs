﻿namespace GestionHuacales.Api.DTO;

public class EntradaHuacalesDetalleDto
{
    public int IdTipo { get; set; }
    public int Cantidad { get; set; }
    public decimal Precio { get; set; }
}
