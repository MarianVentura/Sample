﻿namespace GestionHuacales.Api.Dtos;

public class JugadorRequest
{
    public string Nombres { get; set; }
    public string Email { get; set; }
}