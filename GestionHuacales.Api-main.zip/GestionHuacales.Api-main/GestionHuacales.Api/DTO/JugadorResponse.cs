﻿namespace GestionHuacales.Api.Dtos;

public class JugadorResponse
{
    public int JugadorId { get; set; }
    public string Nombres { get; set; }
    public string Email { get; set; }
}