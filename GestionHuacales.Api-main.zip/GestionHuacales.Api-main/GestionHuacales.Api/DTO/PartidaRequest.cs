﻿namespace GestionHuacales.Api.DTO;

public class PartidaRequest
{ 
    public int Jugador1Id { get; set; }
    public int? Jugador2Id { get; set; }

}