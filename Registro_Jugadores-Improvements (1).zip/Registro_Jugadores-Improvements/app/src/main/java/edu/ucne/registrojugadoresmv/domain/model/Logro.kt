package edu.ucne.registrojugadoresmv.domain.model

data class Logro(
    val logroId: Int = 0,
    val nombre: String = "",
    val descripcion: String = ""
)